import { browser } from "wxt/browser";

export default defineBackground(() => {
  // basic background script
});
